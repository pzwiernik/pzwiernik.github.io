# In this file we check how often the correct tree is found by the structural EM algorithm
# we compare it with how well the chi^2-statistics performs.


## SOME HELFUL LIBRARIES

library(MASS)
library(ape)
library(igraph)
library(expm) # sqrtm
library(miscTools) # symMatrix
library(gdata) # upperTriangle
library(matrixStats)
#setwd("~/Documents/_MyWork/[DPU] latentGaussianTreeMLE/code/Markdown")
install.packages("devtools")
devtools::install_github("pzwiernik/StructuralEM")
library(StructuralEM)

## SOME PARAMETERS
m <- 5 # number of leaves
N <- n <- 200 # sample size

## SOME HELPFUL FUNCTIONS
## this is the index for removing duplicate rows/cols from covariance of minors matrix
keepbin <- c(1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,0,0,0,1,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,1);
keep <- keepbin==1;
## function
perm_parity <- function(p) {
  result <- 0
  k <- length(p)
  for (i in 1:(k-1)) {
    result <- result + sum(0+(p[(i+1):k]<p[i]))
  }
  return((-1)^(result %% 2))
}
# list subsets of size 2
s2 <- list(c(1,2),c(1,3),c(1,4),c(1,5),c(2,3),c(2,4),c(2,5),c(3,4),c(3,5),c(4,5))
s2m <- matrix(unlist(s2),byrow=TRUE,10,2)
## Note: in our simulations we work with 10x10 matrices whose rows and columns are indexed
## by the list s2 defined above.
## Build the covariance of minors for white wishart, Cvs as a tensor --- ONLY NEEDS TO BE run again when change of n
Cvs <- array(NA,c(10,10,10,10))
for (i in 1:10){
  for (j in i:10){ # suppose j>=i
    for (k in i:10){ # suppose k>=i
      for (l in k:10){ #suppose l>=k
        aI <- s2[[i]]; aJ <- s2[[j]]; aK <- s2[[k]]; aL <- s2[[l]]; # sets I,J,K,L
        A <- union(setdiff(aI,aJ),setdiff(aJ,aI));  B <- union(setdiff(aK,aL),setdiff(aL,aK)); # symmetric differences
        if (!(identical(sort(A),sort(B)))){ #A and B must be equal
          Cvs[i,j,k,l] <- 0 ## OK
        } else if (i==k && j==l) {# the diagonal elements!
          if (identical(intersect(aI,aJ),numeric(0))){
            Cvs[i,j,k,l] <- 2/(n*(n-1)) #OK
          } else if (i==j){
            Cvs[i,j,k,l] <- 2*(2*n+1)/(n*(n-1)) ## OK
          } else {
            Cvs[i,j,k,l]<-(n+2)/(n*(n-1)) # OK
          }
        } else {
          # A=\emptyset
          if (i==j && identical(intersect(aI,aK),numeric(0))){
            Cvs[i,j,k,l] <- 0 #OK
          }else if (i==j && !(identical(intersect(aI,aK),numeric(0)))){
            Cvs[i,j,k,l]<- 2/n #OK
          } else {
            if (identical(intersect(aI,aJ),numeric(0))) {
              par <- perm_parity(c(intersect(aI,aK),intersect(aI,aL),intersect(aJ,aK),intersect(aJ,aL)))
            } else {
              par <- perm_parity(c(intersect(aI,aJ),setdiff(aI,aJ),setdiff(aJ,aI),intersect(aK,aL)))
            }
            Cvs[i,j,k,l] <- par*((n-1)^(1-length(A)/2))/n
          }
        }
      }
    }
  }
}
for (i in 1:10){
  for (j in 1:10){
    for (k in 1:10){
      for (l in 1:10){
        # first fill all the remaining table, where i<=k
        if (i>j && k<=l && i<=k) {Cvs[i,j,k,l] <- Cvs[j,i,k,l]}
        if (i<=j && k>l && i<=k && i<=l) {Cvs[i,j,k,l] <- Cvs[i,j,l,k]}
        if (i<=j && k>l && i<=k && i>l) {Cvs[i,j,k,l] <- Cvs[l,k,i,j]}
        if (i>j && k>l && i<=k && j<=l) {Cvs[i,j,k,l] <- Cvs[j,i,l,k]}
        if (i>j && k>l && i<=k && j>l) {Cvs[i,j,k,l] <- Cvs[l,k,j,i]}
        # now the rest
        if (i>k) {Cvs[i,j,k,l] <- Cvs[k,l,i,j]}
      }
    }
  }
}
# flatten 10x10x10x10 tensor to a 100x100 matrix
# LATER: make sure aperm does its job # it does!
# flCvs <- matrix(c(aperm(Cvs)),byrow=TRUE,100,100)
flCvs <- Cvs*((n-1)/n)^2
dim(flCvs) <- c(100,100)

## THE MAIN PART OF THE SIMULATION
# generate a random tree (with edge lengths) and some data
# from the induced correlation matrix
#Ttr <- rtree(m,rooted=FALSE,min=-log(.5),max=1)
set.seed(4)
Ttr <- ape::rtree(m,rooted=FALSE,br=rep(-log(.7),7))
Ttr$tip.label <- 1:m # label leaves by 1:m
Str <- get.corr0(Ttr)
Rtr <- Str[1:m,1:m]

iters <- 100 # number of iterations
count <- matrix(0,2,iters) # count of how many times a coorect tree is identified
for (it in 1:iters){

  dat <- MASS::mvrnorm(N, rep(0,m), Rtr)
  # normalize the sampled data
  dat <- normalize.data(dat)
  S <- t(dat)%*%dat # scatter matrix


  # quickly compute the starting point
  # in the current version we use fastme.bal()
  # from teh ape package
  D <- get.dist(cor(dat))
  T0 <- ape::fastme.bal(D)
  #since the algorithm may produce negative lengths
  # we replace all those instances by zeros
  T0$edge.length <- (T0$edge.length>0)*T0$edge.length

  #ptm <- proc.time()
  res <- strEM(dat,T0,tol=1e-6)
  #print(proc.time() - ptm)
  #plot(res$tree)

  if (igraph::shortest.paths(res$tree,1,2,weights=NA)==2 && igraph::shortest.paths(res$tree,4,5,weights=NA)==2){
    count[1,it] <- 1
  }

  #### THE METHOD OF MINORS
  ## compute 2-minors of S
  minors <- matrix(0,10,10)
  for (i in 1:10){
    for (j in i:10){
      minors[j,i] <- minors[i,j] <- det(S[s2[[i]],s2[[j]]])/(n*(n-1))  # compute all Q_{I,J}
    }
  }
  rownames(minors) <- colnames(minors) <- c("12","13","14","15","23","24","25","34","35","45")
  ## compute 2-minors of S^{1/2}
  Sq <- sqrtm(S)/sqrt(n)
  minorsq <- matrix(0,10,10)
  for (i in 1:10){
    for (j in i:10){
      minorsq[j,i] <- minorsq[i,j] <- det(Sq[s2[[i]],s2[[j]]])  # compute all Q_{I,J}
    }
  }
  symMatrix(upperTriangle(minorsq, TRUE), byrow = TRUE)


  # Us the white Whishart cov matrix to get the (approximated) covariance matrix of the minors
  kcvms <- kronecker(minorsq,minorsq)%*%flCvs%*%kronecker(minorsq,minorsq)
  ## this is the index for removing duplicate rows/cols from covariance of minors matrix
  kcvms <- kcvms[keep,keep] # remove duplicate lines
  rownames(kcvms) <- colnames(kcvms) <-  c("1212","1213","1214","1215","1223","1224","1225","1234","1235","1245",
                                           "1313","1314","1315","1323","1324","1325","1334","1335","1345",
                                           "1414","1415","1423","1424","1425","1434","1435","1445",
                                           "1515","1523","1524","1525","1534","1535","1545",
                                           "2323","2324","2325","2334","2335","2345",
                                           "2424","2425","2434","2435","2445",
                                           "2525","2534","2535","2545",
                                           "3434","3435","3445",
                                           "3535","3545",
                                           "4545")
  # This is testing minimal number of three quartets
  quarts <- c("1245","1235","1345")
  tall = t(c(minors["12","45"], minors["12","35"], minors["13","45"]))%*%solve(kcvms[quarts,quarts])%*%c(minors["12","45"], minors["12","35"], minors["13","45"])
  if (pchisq(tall,3)<0.95){count[2,it]<- 1}

}
apply(count,1,sum)


